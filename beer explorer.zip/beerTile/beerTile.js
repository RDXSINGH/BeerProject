import { LightningElement,api } from 'lwc';
export default class BeerTile extends LightningElement {

@api beerRecord;


handleaddCart(){
    
    const addtoCart= new CustomEvent('cart',{
        detail : this.beerRecord.Id
    })
    this.dispatchEvent(addtoCart);
}
}
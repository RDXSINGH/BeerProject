import { LightningElement, track, wire,api } from 'lwc';
import cartIco from '@salesforce/resourceUrl/cart';
import getCartId from '@salesforce/apex/BeerController.getCartId';
import searchBeer from '@salesforce/apex/BeerController.searchBeer';
import createCartItems from '@salesforce/apex/BeerController.createCartItems';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
export default class BeerList extends NavigationMixin(LightningElement) {

    @track beerRecords;
    @track errros;
    @track cart = cartIco;
    @track itemsinCart = 0;
    @track cartId;
     @track cartUrl = '#';
    connectedCallback(){
        this.defaultCartId();
       // this.generateCartUrl();
    } 

    // generateCartUrl() {
    //     const pageRef = {
    //         type: 'standard__navItemPage',
    //         attributes: {
    //             apiName: 'Cart_Details'
    //         },
    //         state: {
    //             c__cartId: this.cartId
    //         }
    //     };

    //     this[NavigationMixin.GenerateUrl](pageRef)
    //         .then(url => {
    //             this.cartUrl = url;
    //         })
    //         .catch(error => {
    //             console.error('Error generating URL', error);
    //         });
    // }

    defaultCartId(){
        getCartId()
        .then(data => {
            const wrapper = JSON.parse(data);
            if ( wrapper ){
               this.itemsinCart = wrapper.Count;
                console.log('this.cartId' + wrapper.CartId);
                this.cartId = wrapper.CartId;
            }
        })
        .catch(error => {
            this.cartId = undefined;
            console.log(error);
        });
    }



   addToCart(event){
        const selectBeerId = event.detail;
        const selectBeerRecord = this.beerRecords.find(
            record => record.Id === selectBeerId
        );
        /*
            for(Beer__c beer : beerRecords ){
                if(beer.Id == selectBeerId ){
                    return beer;
                }
            }
        */

        createCartItems({
            CartId : this.cartId,
            BeerId : selectBeerId,
            Amount : selectBeerRecord.Price__c
        })
        .then(data => {
         //   console.log(' Cart Item Id??>> ', data);
            this.itemsinCart = this.itemsinCart + 1;

             const toast = new ShowToastEvent({
                'title' : 'Success!!',
                "message" : selectBeerRecord.Name +' Added into Cart!',
                "variant" : "success", 
            });
            this.dispatchEvent(toast);
        })
        .catch(error => {
            console.log(error);
            const toast = new ShowToastEvent({
                'title' : 'Error!!',
                "message" : JSON.stringify(error),
                "variant" : "error", 
            });
            this.dispatchEvent(toast);
        });

    }
    

handleCartClick(event) {
    // event.preventDefault();
    this.navigateToCartDetail();
    console.log('kishan nav to cart url', this.cartUrl);
     console.log('kishan nav to new tab', this.cartId);
        
        // if (this.cartUrl && this.cartUrl !== '#') {
        //     window.open(this.cartUrl, '_blank');
        // }
}

     navigateToCartDetail(){

        console.log('ksihan nav');
        this[NavigationMixin.Navigate]({
            type: 'standard__navItemPage',
            attributes: {
                apiName: 'Cart_Details' // Cart Detail
            },
            state : {
                c__cartId : this.cartId
            }
        });
    }

    @wire(searchBeer)
    wiredRecords({ error, data }) {
        
        this.beerRecords = data;
        // console.log('beerdata',this.beerRecords );
        // console.log('beerjson', JSON.stringify(this.beerRecords));
        this.errors = error;
    }

    handleEvent(event) {
        const eventVal = event.detail;
        searchBeer({
            searchParam: eventVal
        }).then(result => {
            console.log('result>>', result);
            this.beerRecords = result;
            this.errros = undefined;
        }).catch(error => {
            console.log('error', error);
            this.beerRecords = undefined;
            this.errros = error;
        })

    }

}